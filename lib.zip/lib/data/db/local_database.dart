// import 'package:sqflite/sqflite.dart';
// import 'package:path/path.dart';
// import 'package:up_todo/models/cached_category.dart';
// import 'package:up_todo/models/cached_to_do.dart';

// class LocalDataBase {
//   static final LocalDataBase getInstance = LocalDataBase._init();
//   LocalDataBase._init();
//   static Database? _database;

//   Future<Database> get database async {
//     if (_database != null) {
//       return _database!;
//     } else {
//       _database = await _initDB("todos.db");
//       return _database!;
//     }
//   }

//   Future<Database> _initDB(String fileName) async {
//     final dbPath = await getDatabasesPath();
//     final String totalPath = join(dbPath, fileName);
//     return await openDatabase(totalPath, version: 1, onCreate: _createDB);
//   }

//   Future _createDB(Database db, int version) async {
//     const idType = "INTEGER PRIMARY KEY AUTOINCREMENT";
//     const textType = "TEXT NOT NULL";
//     const intType = "INTEGER NOT NULL";

//     /// Creating todo table
//     await db.execute('''
//     CREATE TABLE ${CachedToDoFields.tableName} (
//     ${CachedToDoFields.id} $idType,
//     ${CachedToDoFields.categoryId} $intType,
//     ${CachedToDoFields.title} $textType,
//     ${CachedToDoFields.description} $textType,
//     ${CachedToDoFields.dateTime} $textType,
//     ${CachedToDoFields.isDone} $intType,
//     ${CachedToDoFields.taskPriority} $intType
//     )
//     ''');

//     /// Creating category table
//     await db.execute('''
//     CREATE TABLE ${CachedCategoryFields.tableName} (
//     ${CachedCategoryFields.id} $idType,
//     ${CachedCategoryFields.categoryColor} $textType,
//     ${CachedCategoryFields.iconColor} $textType,
//     ${CachedCategoryFields.iconPath} $textType,
//     ${CachedCategoryFields.title} $textType
//     )
//     ''');
//   }

//   // -------------------------- Cached ToDo services ----------------------------

//   static Future<List<CachedTodo>> getAllToDos() async {
//     final db = await getInstance.database;
//     const orderBy = "${CachedToDoFields.taskPriority} ASC";
//     final toDos = await db.query(CachedToDoFields.tableName, orderBy: orderBy);
//     return toDos.map((json) => CachedTodo.fromJson(json)).toList();
//   }

//   static Future<CachedTodo> insertCacheToDo(CachedTodo cachedTodo) async {
//     final db = await getInstance.database;
//     final id = await db.insert(CachedToDoFields.tableName, cachedTodo.toJson());
//     return cachedTodo.copyWith(id: id);
//   }

//   static Future<int> updateCachedTodoStatus(int id, int status) async {
//     Map<String, dynamic> row = {
//       CachedToDoFields.isDone: status,
//     };

//     final db = await getInstance.database;
//     return db.update(
//       CachedToDoFields.tableName,
//       row,
//       where: '${CachedToDoFields.id} = ?',
//       whereArgs: [id],
//     );
//   }

//   static Future<int> deleteCachedTodoById(int id) async {
//     final db = await getInstance.database;
//     var t = await db.delete(CachedToDoFields.tableName,
//         where: "${CachedToDoFields.id}=?", whereArgs: [id]);
//     if (t > 0) {
//       return t;
//     } else {
//       return -1;
//     }
//   }

//   static Future<int> updateCachedTodo(
//       {required int id, required CachedTodo cachedTodo}) async {
//     Map<String, Object?> toDo = cachedTodo.toJson();
//     Map<String, dynamic> row = {
//       CachedToDoFields.isDone: toDo[CachedToDoFields.isDone],
//       CachedToDoFields.title: toDo[CachedToDoFields.title],
//       CachedToDoFields.description:toDo[CachedToDoFields.description],
//       CachedToDoFields.categoryId: toDo[CachedToDoFields.categoryId],
//       CachedToDoFields.taskPriority: toDo[CachedToDoFields.taskPriority],
//       CachedToDoFields.dateTime: toDo[CachedToDoFields.dateTime],
//     };

//     final db = await getInstance.database;
//     return db.update(
//       CachedToDoFields.tableName,
//       row,
//       where: '${CachedToDoFields.id} = ?',
//       whereArgs: [id],
//     );
//   }

//   // ------------------------ Cached Category services -----------------------

//   static Future<CachedCategorie> insertCachedCategory(
//       CachedCategorie cachedCategorie) async {
//     final db = await getInstance.database;
//     final id = await db.insert(
//         CachedCategoryFields.tableName, cachedCategorie.toJson());
//     return cachedCategorie.copyWith(id: id);
//   }

//   static Future<List<CachedCategorie>> getAllCategories() async {
//     final db = await getInstance.database;
//     final categories = await db.query(CachedCategoryFields.tableName);
//     return categories.map((json) => CachedCategorie.fromJson(json)).toList();
//   }

//   static Future<CachedCategorie> getSingleCategoryById(int id) async {
//     final db = await getInstance.database;
//     final results = await db.query(
//       CachedCategoryFields.tableName,
//       where: '${CachedCategoryFields.id} = ?',
//       whereArgs: [id],
//     );
//     if (results.isNotEmpty) {
//       return CachedCategorie.fromJson(results.first);
//     } else {
//       throw Exception('ID $id not found');
//     }
//   }
// }
