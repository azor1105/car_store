class CarModelDataBase {
  int? id;
  bool isFavourite;
  String companyName;
  int companyId;
  String logoUrl;
  int establishedYear;
  int price;

  CarModelDataBase({
    required this.companyId,
    required this.companyName,
    required this.id,
    required this.isFavourite,
    required this.logoUrl,
    required this.establishedYear,
    required this.price,
  });

  static CarModelDataBase fromJson(Map<String, Object?> json) {
    return CarModelDataBase(
      price: json['average_price'] as int? ?? 0,
      establishedYear: json['established_year'] as int? ?? 0,
      companyId: json['company_id'] as int? ?? 0,
      companyName: json['company_name'] as String? ?? '',
      id: json['id'] as int? ?? 0,
      isFavourite: (json['is_favourite'] as int? ?? 0) == 1,
      logoUrl: json['logo_url'] as String? ?? '',
    );
  }
}
